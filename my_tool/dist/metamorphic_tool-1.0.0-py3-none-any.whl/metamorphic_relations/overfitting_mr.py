
import numpy as np
import tensorflow as tf
import os
import cv2
from PIL import Image
from io import BytesIO
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Dense, Conv2D, BatchNormalization, Dropout, MaxPool2D, Input, Softmax, Activation, Flatten
from tensorflow.keras.models import Model
from tensorflow.keras.preprocessing.image import ImageDataGenerator
from tensorflow.keras.layers import MaxPooling2D
from tensorflow.keras.utils import to_categorical
import tensorflow as tf

class overfitting_MR:

	def __init__(self, classifier_path, dataset_path, height, width):
		self.classifier_path = classifier_path
		self.dataset_path = dataset_path
		self.height = height
		self.width = width

	def output(self):
		data=[]
		labels=[]
		path = self.dataset_path        #'/home/razorback/BTP/metamorphic_testing/meta_relations/data/TRAIN/'
		model = tf.keras.models.load_model(self.classifier_path)
		channels = 3
		classes = len(os.listdir(path))
		model_shape = model.layers[0].input_shape

		#Loading of dataset from the given path
		for i in range(classes):
			images = os.listdir(path+'/'+str(i))

			for image in images:
				
				img = cv2.imread(path+'/'+str(i)+'/'+image)
				#print(img)
				if img is not None:
				        im = Image.fromarray(img)
				        img_arr = np.array(im.resize((int(self.height), int(self.width)), Image.BICUBIC))
				        data.append(img_arr)
				        labels.append(i)
					

		Cells=np.asarray(data)
		labels=np.array(labels)

		s=np.arange(Cells.shape[0])
		np.random.seed(43)
		np.random.shuffle(s)
		Cells=Cells[s]
		labels=labels[s]

		#Data Augmentation Procedure

		(X_train,X_val)=Cells[(int)(0.2*len(labels)):],Cells[:(int)(0.2*len(labels))]
		X_train = X_train.astype('float32')/255 
		X_val = X_val.astype('float32')/255
		(y_train,y_val)=labels[(int)(0.2*len(labels)):],labels[:(int)(0.2*len(labels))]

		y_train = to_categorical(y_train, classes)
		y_val = to_categorical(y_val, classes)

		num_layers = len(model.layers)
		model1 = Sequential()
		model1.add(Conv2D(filters=16, kernel_size=(5,5), strides=(2,2), activation='relu', input_shape=X_train.shape[1:]))
		model1.add(Conv2D(filters=32, kernel_size=(5,5), strides=(2,2), activation='relu'))
		model1.add(Flatten())
		model1.add(Dense(128, activation='relu'))
		model1.add(Dense(classes, activation='softmax'))

		model1.compile(
		    loss='categorical_crossentropy', 
		    optimizer='adam', 
		    metrics=['accuracy']
		)

		#Validating your model against the validation data set
		epochs = 1
		history = model1.fit(X_train, y_train, batch_size=32, epochs=epochs,
		validation_data=(X_val, y_val))

		model2 = Sequential()
		model2.add(Conv2D(filters=16, kernel_size=(5,5), strides=(2,2), activation='relu', input_shape=X_train.shape[1:]))
		model2.add(Conv2D(filters=32, kernel_size=(5,5), strides=(2,2), activation='relu'))
		model2.add(Flatten())
		model2.add(Dense(128, kernel_regularizer=regularizers.l2(0.001), activation='relu'))
		model2.add(Dense(classes, kernel_regularizer=regularizers.l2(0.001), activation='softmax'))

		model2.compile(
		    loss='categorical_crossentropy', 
		    optimizer='adam', 
		    metrics=['accuracy']
		)

		#Validating your model against the validation data set
		epochs = 1
		history = model2.fit(X_train, y_train, batch_size=32, epochs=epochs,
		validation_data=(X_val, y_val))

		model3 = Sequential()
		model3.add(Conv2D(filters=16, kernel_size=(5,5), strides=(2,2), activation='relu', input_shape=X_train.shape[1:]))
		model3.add(Dropout(rate=0.25))
		model3.add(Conv2D(filters=32, kernel_size=(5,5), strides=(2,2), activation='relu'))
		model3.add(Dropout(rate=0.25))
		model3.add(Flatten())
		model3.add(Dense(128, activation='relu'))
		model3.add(Dropout(rate=0.25))
		model3.add(Dense(classes, activation='softmax'))

		model3.compile(
		    loss='categorical_crossentropy', 
		    optimizer='adam', 
		    metrics=['accuracy']
		)

		#Validating your model against the validation data set
		epochs = 1
		history = model3.fit(X_train, y_train, batch_size=32, epochs=epochs,
		validation_data=(X_val, y_val))


