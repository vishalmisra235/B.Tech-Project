
import os
import random
import cv2
from collections import defaultdict
from tensorflow.keras.utils import to_categorical
from PIL import Image
import tensorflow as tf

class bias_MR:

	def __init__(self, classifier_path, dataset_path, height, width):
		self.classifier_path = classifier_path
		self.dataset_path = dataset_path
		self.height = height
		self.width = width

	def output(self):
		no_of_classes = len(os.listdir(self.dataset_path))
		model = tf.keras.models.load_model(self.classifier_path)
		path = self.dataset_path

		no_of_samples = 0
		for i in range(no_of_classes):
			num_images = len(os.listdir(os.path.join(path,str(i))))
			no_of_samples = no_of_samples + num_images
		    

		    
		d_1=[]
		l_1=[]
		d_2=[]
		l_2=[]
		d_3=[]
		l_3=[]

		for j in range(no_of_samples):
			category = random.randint(0,no_of_classes-1)
			new_path = os.path.join(path,str(category))
			images = len(os.listdir(new_path))
			img = random.randint(0,images-1)        
			d_1.append(category)
			l_1.append(img)
		    
		print(len(d_1))
		print(len(l_1))

		for j in range(no_of_samples):
			category = random.randint(0,no_of_classes-1)
			new_path = os.path.join(path,str(category))
			images = len(os.listdir(new_path))
			img = random.randint(0,images-1)        
			d_2.append(category)
			l_2.append(img)
		    
		for j in range(no_of_samples):
			category = random.randint(0,no_of_classes-1)
			new_path = os.path.join(path,str(category))
			images = len(os.listdir(new_path))
			img = random.randint(0,images-1)        
			d_3.append(category)
			l_3.append(img)

		p_1=[]
		p_2=[]
		p_3=[]

		data_1=[]
		data_2=[]
		data_3=[]

		c=0
		for c in range(len(d_1)):
			images = os.listdir(os.path.join(path,str(d_1[c])))
			d=0
			for img in images:
				if d!=l_1[c]:
					d=d+1
					continue
				im = cv2.imread(os.path.join(path,str(d_1[c]),img))
				im = Image.fromarray(im)
				img_arr = np.array(im.resize((int(self.height), int(self.width)), Image.BICUBIC))
				data_1.append(img_arr)
				break
		    
		print(len(data_1))
		c=0
		for c in range(len(d_2)):
			images = os.listdir(os.path.join(path,str(d_2[c])))
			d=0
			for img in images:
				if d!=l_2[c]:
					d=d+1
					continue
				im = cv2.imread(os.path.join(path,str(d_2[c]),img))
				im = Image.fromarray(im)
				img_arr = np.array(im.resize((int(self.height), int(self.width)), Image.BICUBIC))
				data_2.append(img_arr)
				break

		c=0        
		for c in range(len(d_3)):
			images = os.listdir(os.path.join(path,str(d_3[c])))
			d=0
			for img in images:
				if d!=l_3[c]:
					d=d+1
					continue
				im = cv2.imread(os.path.join(path,str(d_3[c]),img))
				im = Image.fromarray(im)
				img_arr = np.array(im.resize((int(self.height), int(self.width)), Image.BICUBIC))
				data_3.append(img_arr)
				break

		model.fit(np.asarray(data_1), to_categorical(np.asarray(d_1),no_of_classes), epochs=8, verbose=1)
		p_1 = model.predict(X_val)

		model.fit(np.asarray(data_2), to_categorical(np.asarray(d_2),no_of_classes), epochs=8, verbose=1)
		p_2 = model.predict(X_val)

		model.fit(np.asarray(data_3), to_categorical(np.asarray(d_3),no_of_classes), epochs=8, verbose=1)
		p_3 = model.predict(X_val)

		print('Ending of Bias MR')

