
import os
import tensorflow as tf
from keras.preprocessing import image
from keras.applications.imagenet_utils import decode_predictions
from skimage.io import imread
import matplotlib.pyplot as plt
import numpy as np
import os,sys
import lime
from lime import lime_image

class interpretability_MR:

	def __init__(self, classifier_path, dataset_path, height, width):
		self.classifier_path = classifier_path
		self.dataset_path = dataset_path
		self.height = height
		self.width = width


	def output(self):
		classes = len(os.listdir(self.dataset_path))
		model = tf.keras.models.load_model(self.classifier_path)
		path = self.dataset_path


		images = []
		num_classes = len(os.listdir(path))
		for i in range(num_classes):
			newpath_list = os.path.join(path,str(i))
			for img_path in os.listdir(newpath_list):
				img = image.load_img(os.path.join(newpath_list,img_path), target_size=(int(self.height), int(self.width)))
				x = image.img_to_array(img)
				x = np.expand_dims(x, axis=0)
				images.append(x)


		explainer = lime_image.LimeImageExplainer()

		explanation = explainer.explain_instance(images[123], model.predict, top_labels=5, hide_color=0, num_samples=1000)

		from skimage.segmentation import mark_boundaries

		temp, mask = explanation.get_image_and_mask(explanation.top_labels[0], positive_only=True, num_features=5, hide_rest=True)
		plt.imshow(mark_boundaries(temp / 2 + 0.5, mask))
		plt.show()

		temp, mask = explanation.get_image_and_mask(explanation.top_labels[0], positive_only=True, num_features=5, hide_rest=False)
		plt.imshow(mark_boundaries(temp / 2 + 0.5, mask))
		plt.show()

		temp, mask = explanation.get_image_and_mask(explanation.top_labels[0], positive_only=False, num_features=10, hide_rest=False)
		plt.imshow(mark_boundaries(temp / 2 + 0.5, mask))
		plt.show()

		print('Ending of Interpretability MR')
