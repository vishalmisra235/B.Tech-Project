import matplotlib.pyplot as plt
from sklearn.cluster import KMeans
from sklearn.decomposition import PCA
from sklearn.preprocessing import StandardScaler
import tensorflow as tf
import numpy as np
import pandas as pd
import os
import cv2
from PIL import Image
from keras.applications.imagenet_utils import preprocess_input
from tensorflow.keras.models import Model
from tensorflow.keras.utils import to_categorical

class outliers_MR:

	def __init__(self, classifier_path, dataset_path, height, width):
		self.classifier_path = classifier_path
		self.dataset_path = dataset_path
		self.height = height
		self.width = width

	def output(self):
		num_classes = len(os.listdir(self.dataset_path))
		model = tf.keras.models.load_model(self.classifier_path)
		path = self.dataset_path
		indices=[]
		data=[]
		for i in range(num_classes):
			new_path = os.path.join(path,str(i))
			images = next(os.walk(new_path))[2]
			for image in images:
				im = cv2.imread(os.path.join(new_path,image))
				im = cv2.resize(im,(int(self.height),int(self.width)))
				img = preprocess_input(np.expand_dims(im.copy(), axis=0))
				feature = model.predict(img)
				feature_np = np.array(feature)
				data.append(feature_np.flatten())

		print(np.asarray(data).shape)

		kmeans = KMeans(n_clusters=num_classes, random_state=0).fit(np.asarray(data))

		y_kmeans = kmeans.predict(np.asarray(data))
		data = np.asarray(data)
		plt.scatter(data[:,0], data[:,1], c=kmeans.labels_, cmap='rainbow')
		plt.scatter(kmeans.cluster_centers_[:,0] ,kmeans.cluster_centers_[:,1], color='black')
		plt.show()

		new_data=[]
		new_labels=[]
		path = self.dataset_path
		for i in range(num_classes):
			path = self.dataset_path
			images = os.listdir(os.path.join(path,str(i)))
			data=[]
			labels=[]
			for image in images:
				
				img = cv2.imread(os.path.join(path,str(i),image))
				#print(img)
				if img is not None:
				        im = Image.fromarray(img)
				        img_arr = np.array(im.resize((int(self.height),int(self.width)), Image.BICUBIC))
				        data.append(img_arr)
				        labels.append(i)
					
			data=np.asarray(data)
			labels = np.asarray(labels)
			ndata=[]
			for i in data:
				if abs(i.all() - np.mean(data)) < 4 * np.std(data):
					ndata.append(i)
			ndata=np.asarray(ndata)
			i=0
			j=0
			while i<len(ndata):
				new_data.append(ndata[i])
				i=i+1

			i=0
			while i<len(ndata) and j<len(data):
				if ndata[i].all()==data[j].all():
					new_labels.append(labels[i])
					i=i+1
					j=j+1
				else:
					j=j+1

		new_data = np.asarray(new_data)
		new_labels = np.asarray(new_labels)	
		(X_train,X_val)=new_data[(int)(0.2*len(new_labels)):],new_data[:(int)(0.2*len(new_labels))]
		X_train = X_train.astype('float32')/255 
		X_val = X_val.astype('float32')/255
		(y_train,y_val)=new_labels[(int)(0.2*len(new_labels)):],new_labels[:(int)(0.2*len(new_labels))]

		y_train = to_categorical(y_train, num_classes)
		y_val = to_categorical(y_val, num_classes)

		epochs = 1
		history = model.fit(X_train, y_train, batch_size=32, epochs=epochs,
		validation_data=(X_val, y_val))

		print("Ending of Outliers Metamorphiv Relation")






			
