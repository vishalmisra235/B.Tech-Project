'''
Metamorphic Relation 8:
Changing the stride distances of the CNN classifier and checking the accuracy 
'''

import os
import cv2
import scipy.misc
import numpy as np
import json
from PIL import Image
import warnings
warnings.filterwarnings('ignore')
import tensorflow as tf
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Dense, Conv2D, BatchNormalization, Dropout, MaxPool2D, Input, Softmax, Activation, Flatten
from tensorflow.keras.models import Model
from tensorflow.keras.preprocessing.image import ImageDataGenerator
from tensorflow.keras.layers import MaxPooling2D
from tensorflow.keras.utils import to_categorical
from tensorflow.keras.models import model_from_json

class MR8:

	def __init__(self, classifier_path, dataset_path, height, width):
		self.classifier_path = classifier_path
		self.dataset_path = dataset_path
		self.height = height
		self.width = width

	def output(self):
		num_classes = len(os.listdir(self.dataset_path))
		model = tf.keras.models.load_model(self.classifier_path)
		path = self.dataset_path
		data = []
		labels = []
		model_shape = model.layers[0].input_shape
		print(model_shape)

		for i in range(num_classes):
			new_path = os.path.join(path,str(i))
			images = next(os.walk(new_path))[2]
			num_images = len(images)

			for image in images:
				img = cv2.imread(os.path.join(new_path,image))
				if img is not None:
					im = Image.fromarray(img)
					img_arr = np.array(im.resize((int(self.height), int(self.width)), Image.BICUBIC))
					img_arr = np.asarray(img_arr)
					data.append(img_arr)
					labels.append(i)


		Cells=np.asarray(data)
		labels=np.array(labels)


		(Xnew_train,Xnew_val)=Cells[(int)(0.2*len(labels)):],Cells[:(int)(0.2*len(labels))]
		Xnew_train = Xnew_train.astype('float32')/255 
		Xnew_val = Xnew_val.astype('float32')/255
		(ynew_train,ynew_val)=labels[(int)(0.2*len(labels)):],labels[:(int)(0.2*len(labels))]

		ynew_train = to_categorical(ynew_train, num_classes)
		ynew_val = to_categorical(ynew_val, num_classes)

		epochs = 1
		stride_dist = [2,3]

		#standard pipeline model
		for stride in stride_dist:
			model_new = Sequential([
			    Conv2D(16, 3, strides=[stride,stride], padding='same', activation='relu', 
				   input_shape=model_shape[1:]),
			    MaxPooling2D(),
			    Dropout(0.2),
			    Conv2D(32, 3, padding='same', activation='relu'),
			    MaxPooling2D(),
			    Conv2D(64, 3, padding='same', activation='relu'),
			    MaxPooling2D(),
			    Dropout(0.2),
			    Flatten(),
			    Dense(512, activation='relu'),
			    Dense(num_classes, activation='softmax')
			])

			model_new.compile(optimizer='adam',loss='binary_crossentropy',metrics=['accuracy'])

			history = model_new.fit(Xnew_train, ynew_train, batch_size=32, epochs=epochs, validation_data=(Xnew_val, ynew_val))



				
			

			
			




