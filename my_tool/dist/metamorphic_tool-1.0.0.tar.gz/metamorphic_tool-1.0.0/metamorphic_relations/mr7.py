'''
Metamorphic Relation 5:
Creating a new category of class by duplicating any random class and comparing the accuracy 
'''
from PIL import Image
import os
import cv2
import numpy as np
import warnings
warnings.filterwarnings('ignore')
import random
from shutil import copyfile
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Dense, Conv2D, BatchNormalization, Dropout, MaxPool2D, Input, Softmax, Activation, Flatten
from tensorflow.keras.models import Model
from tensorflow.keras.preprocessing.image import ImageDataGenerator
from tensorflow.keras.layers import MaxPooling2D
from tensorflow.keras.utils import to_categorical
from tensorflow.keras.models import model_from_json
import tensorflow as tf

class MR7:

	def __init__(self, classifier_path, dataset_path, height, width):
		self.classifier_path = classifier_path
		self.dataset_path = dataset_path
		self.height = height
		self.width = width

	def output(self):
		num_classes = len(os.listdir(self.dataset_path))
		model = tf.keras.models.load_model(self.classifier_path)
		path = self.dataset_path
		data = []
		labels = []
		model_shape = model.layers[0].input_shape

		#We randomly chose any class and create a new category and add it in our dataset
		dir1 = random.randint(0,num_classes-1)
		print(dir1)
		path1 = os.path.join(path,str(dir1))
		images1 = next(os.walk(path1))[2]
		file_path = os.path.join(path,str(num_classes),images1[0])
		directory = os.path.dirname(file_path)
		if not os.path.exists(directory):
			print(directory)
			os.mkdir(directory)

		images1 = next(os.walk(path1))[2]
		for image in images1:
			img = os.path.join(path1,image)
			copyfile(img,os.path.join(path,str(num_classes),image))

		for i in range(num_classes+1):
			new_path = os.path.join(path,str(i))
			images = next(os.walk(new_path))[2]
			num_images = len(images)

			for image in images:
				img = cv2.imread(os.path.join(new_path,image))
				if img is not None:
					im = Image.fromarray(img)
					img_arr = np.array(im.resize((int(self.height), int(self.width)), Image.BICUBIC))
					img_arr = np.asarray(img_arr)
					data.append(img_arr)
					labels.append(i)


		Cells=np.asarray(data)
		labels=np.array(labels)


		(Xnew_train,Xnew_val)=Cells[(int)(0.2*len(labels)):],Cells[:(int)(0.2*len(labels))]
		Xnew_train = Xnew_train.astype('float32')/255 
		Xnew_val = Xnew_val.astype('float32')/255
		(ynew_train,ynew_val)=labels[(int)(0.2*len(labels)):],labels[:(int)(0.2*len(labels))]

		ynew_train = to_categorical(ynew_train, num_classes+1)
		ynew_val = to_categorical(ynew_val, num_classes+1)

		epochs = 1

		base_output = model.layers[-1].output
		new_output = Dense(num_classes+1, activation="softmax")(base_output)
		model2 = Model(inputs=model.inputs, outputs=new_output)

		model2.compile(loss='categorical_crossentropy',
				  optimizer='adam',
				  metrics=['accuracy'])
		model2.summary()

		history1 = model2.fit(Xnew_train, ynew_train, batch_size=32, epochs=epochs, validation_data=(Xnew_val, ynew_val))

