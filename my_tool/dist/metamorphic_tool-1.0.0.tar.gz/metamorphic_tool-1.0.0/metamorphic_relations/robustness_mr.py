
from art.attacks import FastGradientMethod
from art.classifiers import KerasClassifier

import numpy as np
import pandas as pd

import warnings
warnings.filterwarnings('ignore')

import os
import cv2
from PIL import Image
import tensorflow as tf
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Dense, Conv2D, BatchNormalization, Dropout, MaxPool2D, Input, Softmax, Activation, Flatten
from tensorflow.keras.models import Model
from tensorflow.keras.preprocessing.image import ImageDataGenerator
from tensorflow.keras.layers import MaxPooling2D
from tensorflow.keras.utils import to_categorical

class robustness_MR:

	def __init__(self, classifier_path, dataset_path, height, width):
		self.classifier_path = classifier_path
		self.dataset_path = dataset_path
		self.height = height
		self.width = width

	def output(self):
		classes = len(os.listdir(self.dataset_path))
		model = tf.keras.models.load_model(self.classifier_path)
		path = self.dataset_path


		classifier = KerasClassifier(model=model, clip_values=(1, 100), use_logits=False)

		channels = 3

		data=[]
		labels=[]
		for i in range(classes):
			images = os.listdir(os.path.join(path,str(i)))

			for image in images:
				
				img = cv2.imread(os.path.join(path,str(i),image))
				#print(img)
				if img is not None:
				        im = Image.fromarray(img)
				        img_arr = np.array(im.resize((int(self.height), int(self.width)), Image.BICUBIC))
				        data.append(img_arr)
				        labels.append(i)
					

		Cells=np.asarray(data)
		print(Cells.shape)
		labels=np.array(labels)

		s=np.arange(Cells.shape[0])
		np.random.seed(43)
		np.random.shuffle(s)
		Cells=Cells[s]
		labels=labels[s]

		#Data Augmentation Procedure

		(X_train,X_val)=Cells[(int)(0.2*len(labels)):],Cells[:(int)(0.2*len(labels))]
		X_train = X_train.astype('float32')/255 
		X_val = X_val.astype('float32')/255
		(y_train,y_val)=labels[(int)(0.2*len(labels)):],labels[:(int)(0.2*len(labels))]

		y_train = to_categorical(y_train, classes)
		y_val = to_categorical(y_val, classes)

		classifier.fit(X_train, y_train, batch_size=64, nb_epochs=3)

		predictions = classifier.predict(X_val)
		accuracy = np.sum(np.argmax(predictions, axis=1) == np.argmax(y_val, axis=1)) / len(y_val)
		print('Accuracy on benign test examples: {}%'.format(accuracy * 100))

		#Generate adversarial test examples
		attack = FastGradientMethod(classifier=classifier, eps=0.2)
		x_test_adv = attack.generate(x=X_val)

		#Evaluate the ART classifier on adversarial test examples
		predictions = classifier.predict(x_test_adv)
		accuracy = np.sum(np.argmax(predictions, axis=1) == np.argmax(y_val, axis=1)) / len(y_val)
		print('Accuracy on adversarial test examples: {}%'.format(accuracy * 100))

		print('Ending of Robustness MR')


